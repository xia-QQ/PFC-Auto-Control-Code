import os
import csv

n = 100  # 修改为您实际的文件夹数量
source_folder = r"E:\PL_XRD_UCS"  #模拟完成的文件夹
csv_file_path = r'E:\cl_xrd\E_u_F.csv'  # 输出E_u_F的csv文件路径




def extract_data_and_save_to_csv(n, source_folder, csv_file_path):
    """
    从文本文件中提取数字并将它们保存到一个csv文件中

    :param n: int, 文件夹的数量
    :param source_folder: str, 包含shiyan1到shiyann文件夹的源文件夹
    :param csv_file_path: str, 输出csv文件的路径
    """
    data = []
    for i in range(1, n+1):
        shiyan_folder = os.path.join(source_folder, f'shiyan{i}')
        txt_file_path = os.path.join(shiyan_folder, 'A.txt')
        
        if os.path.exists(txt_file_path):
            with open(txt_file_path, 'r') as file:
                # 读取并分割文本文件中的三个数字
                numbers = file.read().split()
                if len(numbers) == 3:
                    row = [f'shiyan{i}'] + numbers
                    data.append(row)
                else:
                    print(f"Unexpected data format in: {txt_file_path}")
        else:
            print(f"File not found: {txt_file_path}")
    
    # 保存到csv文件
    with open(csv_file_path, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Experiment', 'Param1', 'Param2', 'Param3'])  # 写入头信息
        writer.writerows(data)  # 写入数据
   
extract_data_and_save_to_csv(n, source_folder, csv_file_path)