import math

def compute_line_endpoints(center, angle, length):
    # 将角度转换为弧度
    angle_rad = math.radians(angle)
    
    # 计算起点和终点的坐标
    x1 = center[0] - length / 2 * math.cos(-angle_rad)
    y1 = center[1] - length / 2 * math.sin(-angle_rad)
    x2 = center[0] + length / 2 * math.cos(-angle_rad)
    y2 = center[1] + length / 2 * math.sin(-angle_rad)
    
    # 返回结果
    start_point = (x1, y1)
    end_point = (x2, y2)
    return start_point, end_point

# 示例
center = (18.5,-12.9)  
angle = 89
length = 11.7
start_point, end_point = compute_line_endpoints(center, angle, length)
print("Start point:", start_point)
print("End point:", end_point)
