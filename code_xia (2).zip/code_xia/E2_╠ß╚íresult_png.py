import os
import shutil
n = 400  # 修改为您实际的文件夹数量
source_folder = r"E:\5LX_XRD_AGE" #模拟完成的文件夹
target_folder = r"E:\cl_xrd\result_png" # 存储图片的文件夹路径

def extract_images(n, source_folder, target_folder):

    if not os.path.exists(target_folder):
        os.mkdir(target_folder)
        
    for i in range(1, n+1):
        shiyan_folder = os.path.join(source_folder, f'shiyan{i}')
        source_image_path = os.path.join(shiyan_folder, 'result.png')
        target_image_path = os.path.join(target_folder, f'shiyan{i}.png')
        
        if os.path.exists(source_image_path):
            shutil.copy2(source_image_path, target_image_path)
        else:
            print(f"File not found: {source_image_path}")

# 使用示例

extract_images(n, source_folder, target_folder)
