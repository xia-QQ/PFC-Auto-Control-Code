import numpy as np
import matplotlib.pyplot as plt

size = 5
# 生成坐标数组
coordinate_array = np.random.rand(size, 2)
coordinate_array[:, 0] = coordinate_array[:, 0] * 41.67 - 21.83  # 对第一列的数字进行变化
coordinate_array[:, 1] = coordinate_array[:, 1] *83.3 - 41.7  # 对第二列的数字进行变化

# 生成整数数组，取值为0-180的均匀分布
integer_array = np.random.randint(0, 181, size)

# 生成满足均值为15，标准差为7的正态分布数组（取值大于0）
mean = 15
std_dev = 7
normal_distribution_array = np.random.normal(mean, std_dev, size)
while any(x <= 0 for x in normal_distribution_array):
    normal_distribution_array = np.random.normal(mean, std_dev, size)
# 尺寸变化，使得裂隙符合试样大小
normal_distribution_array[:] = normal_distribution_array[:]*0.5
# 裂隙生成
for x, y, j, l in zip(coordinate_array[:, 0], coordinate_array[:, 1], integer_array, normal_distribution_array):
    print(f'({x:.1f},{y:.1f})',j,f'{l:.1f}')

# 创建图形和轴
fig, ax = plt.subplots(figsize=(5, 10))
ax.set_xlim([-25, 25])
ax.set_ylim([-50, 50])
ax.axhline(0, color='black',linewidth=0.5)
ax.axvline(0, color='black',linewidth=0.5)


# 绘制长方形
rectangle = plt.Rectangle((-25,-50), 50, 100, fc='white',ec="black")
ax.add_patch(rectangle)

# 在坐标系里面画出线段
for x, y, j, l in zip(coordinate_array[:, 0], coordinate_array[:, 1], integer_array, normal_distribution_array):
    x_end = x + l/2 * np.cos(np.radians(-j))#带上符号即与PFC对应
    y_end = y + l/2 * np.sin(np.radians(-j))
    x_start = x - l/2 * np.cos(np.radians(-j))
    y_start = y - l/2 * np.sin(np.radians(-j))
    ax.plot([x_start, x_end], [y_start, y_end], 'b-')

# 保存图片到指定路径
fig.savefig(r"D:\desktop\试样图\1.png", dpi=300)
plt.show()
