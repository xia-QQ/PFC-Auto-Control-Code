import torch
import torch.nn as nn
import pandas as pd
from sklearn.preprocessing import StandardScaler
import numpy as np
import csv

liewen_num = 5#裂纹数量，需要修改
# 加载数据
data = pd.read_csv("E:\cl_xrd\合并数据X.csv", encoding='gbk')#最终得到的UCS+UC+裂纹参数文件，需要修改
model_pth = "E:\cl_xrd\model.pth"#训练导出的pth
yanzheng_path = r"E:\cl_xrd\合并数据验证.csv"#验证数据集文件


# 使用所有20个特征列
columns = ["Column"+str(i) for i in range(1,liewen_num*4+1)]
x_data = data[columns].values
y_data = data[["Min_Value", "Related_Value"]].values

# 标准化特征
scaler_x = StandardScaler()
x_data_scaled = scaler_x.fit_transform(x_data)

# 标准化后的数据
scaler_y = StandardScaler()
y_data_scaled = scaler_y.fit_transform(y_data)

# 定义神经网络模型
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3)
        self.fc1 = nn.Linear(16, 64)
        self.fc2 = nn.Linear(64, 2)
    
    def forward(self, x):
        x = self.conv1(x)
        x = nn.functional.relu(x)
        x = nn.functional.max_pool1d(x, kernel_size=x.size(-1))
        x = x.view(x.size(0), -1)
        x = nn.functional.relu(self.fc1(x))
        x = self.fc2(x)
        return x

model = CNN()
model.load_state_dict(torch.load(model_pth))
model.eval()

# 从另一个CSV中读取新的输入数据
input_date = pd.read_csv(yanzheng_path, encoding='gbk')
x_date = input_date[columns].values
date_list = []

for new_data_row in x_date:
    # 将数据行转化为NumPy数组
    new_data = np.array([new_data_row])
    
    # 对新数据进行标准化处理
    new_data_scaled = scaler_x.transform(new_data)
    
    # 将新数据转换为张量
    x_new_tensor = torch.tensor(new_data_scaled, dtype=torch.float32).unsqueeze(1)
    
    # 对新数据进行预测
    with torch.no_grad():
        predicted_outputs_scaled = model(x_new_tensor)
        predicted_outputs = scaler_y.inverse_transform(predicted_outputs_scaled.numpy())  # 反标准化预测结果

    date_list.append(predicted_outputs)
    print("Predicted Outputs:", predicted_outputs) 

# 更新预测结果到CSV文件
csv_filename = yanzheng_path
with open(csv_filename, mode='r', newline='') as file:
    reader = csv.reader(file)
    rows = list(reader)

rows[0].extend(["预测1", "预测2"])

for i in range(1, len(rows)):
    if i - 1 < len(date_list):
        row_data = date_list[i - 1]
        rows[i].extend(row_data.flatten())

with open(csv_filename, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(rows)
