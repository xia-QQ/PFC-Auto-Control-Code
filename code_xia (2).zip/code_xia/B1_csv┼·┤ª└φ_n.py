import csv
import os

# 创建输出文件夹
output_folder = r"E:\cl_xrd\csv批处理"#输出位置文件夹
input_folder = r"E:\5LX_XRD_AGE"#模拟完成的文件夹
wenjian_num = 400#shiyan文件数，需要修改


os.makedirs(output_folder, exist_ok=True)
# 列名
column_names = ["step", "time", "weyy", "wyss", "total_wexx","crack_num", "crack_tension_n",
                "crack_shear_num", "crack_length", "crack_tension_l", "crack_shear_len", "fragNum", "max_frage_vol"]

# 函数用于确保数字长度为适当长度
def format_value(value, length=10):
    return f"{value:.{length}f}"

# 遍历文件夹中的子文件夹
for folder_index in range(1, wenjian_num+1):
    input_folder_path = os.path.join(input_folder, f"shiyan{folder_index}")
    input_file_path = os.path.join(input_folder_path, "canshu_jihe.csv")
    output_file_path = os.path.join(output_folder, f"{folder_index}.csv")

    with open(input_file_path, 'r') as input_file, open(output_file_path, 'w', newline='') as output_file:
        # 跳过前两行
        next(input_file)
        next(input_file)

        # 创建CSV写入器
        csv_writer = csv.writer(output_file)
        
        # 写入列名
        csv_writer.writerow(column_names)

        # 逐行处理数据
        for line in input_file:
            data = line.strip().split()
            data = [format_value(float(value)) for value in data]
            csv_writer.writerow(data)

print("处理完成！")
