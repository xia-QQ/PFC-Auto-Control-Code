#使用线性回归模型（如scikit-learn的LinearRegression）来估计每个特征对目标值的影响程度。我们将使用回归系数的绝对值来量化每个特征的相对重要性，并按比例调整使总和为100。
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# 读取CSV文件
def read_csv(filename):
    return pd.read_csv(filename)

# 训练模型并获取特征影响程度
def feature_importances(data):
    # 分离目标值和特征值
    X = data.iloc[:, 1:]  # 第一列是目标值，其余是特征值
    y = data.iloc[:, 0]

    # 分割数据，用于训练和验证模型
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # 创建线性回归模型并训练
    model = LinearRegression()
    model.fit(X_train, y_train)

    # 获取回归系数，并根据系数的绝对值计算影响程度
    coefficients = model.coef_
    importances = abs(coefficients) / sum(abs(coefficients)) * 100

    # 返回特征名称和它们的影响程度
    return pd.DataFrame({'Feature': X.columns, 'Importance': importances})

# 主函数
def main():
    # 指定文件名
    filename = r"D:\desktop\h.csv"
    data = read_csv(filename)
    importances = feature_importances(data)
    print(importances)

if __name__ == '__main__':
    main()
