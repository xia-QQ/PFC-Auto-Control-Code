from PIL import Image, ImageDraw
import numpy as np

def process_image(image_path):
    # 打开图片并转为RGB
    im = Image.open(image_path).convert('RGB')
    im_width, im_height = im.size

    # 将图片转换为数组方便处理
    im_np = np.array(im)

    # 找到两个淡蓝色的横线
    blue_lines = []
    for y in range(im_height):
        r, g, b = im_np[y].T  # 将RGB三通道分开
        blue_diff = b - np.mean([r, g], axis=0)
        if np.mean(blue_diff) > 50:  # 通过B通道与其他通道的差异来检测淡蓝色
            blue_lines.append(y)

    # 计算两个横线的中心位置和距离
    top_line, bottom_line = blue_lines[0], blue_lines[-1]
    center = (top_line + bottom_line) // 2
    distance = bottom_line - top_line

    # 重新绘制缩短后的蓝线
    new_distance = int(distance / 1.5)
    new_top_line = center - new_distance // 2
    new_bottom_line = center + new_distance // 2

    draw = ImageDraw.Draw(im)
    draw.line([(0, new_top_line), (im_width, new_top_line)], fill=(173, 216, 230), width=3)
    draw.line([(0, new_bottom_line), (im_width, new_bottom_line)], fill=(173, 216, 230), width=3)


    # 根据黑色线和其他颜色的点来模拟裂纹
    # 注意：这里的处理非常简化，实际操作可能需要更复杂的方法
    for y in range(new_top_line, new_bottom_line):
        for x in range(im_width):
            pixel = im_np[y, x]
            if np.all(pixel < [50, 50, 50]):  # 检测黑色线
                draw.line([(x, y), (x, center)], fill=(0, 0, 0), width=1)
            elif np.all((pixel - [173, 216, 230]) ** 2 < 500):  # 检测蓝色点
                draw.ellipse([(x-2, y-2), (x+2, y+2)], fill=(0, 0, 255), outline=None)
            elif np.all((pixel - [0, 255, 0]) ** 2 < 500):  # 检测绿色点
                draw.ellipse([(x-2, y-2), (x+2, y+2)], fill=(0, 255, 0), outline=None)

    im.save(r"D:\desktop\processed_image.png")

process_image(r"D:\desktop\11.png")
