from PIL import Image
import os

# 文件夹路径
folder1 = r"E:\cl_xrd\jieguo0_png"
folder2 = r"E:\cl_xrd\result_png"
output_folder = r"E:\cl_xrd\merged_gray_png"
wenjian_num = len(os.listdir(folder1))

def crop_image(img):
    # 图片原始尺寸
    width, height = img.size

    # 裁剪的尺寸
    crop_width, crop_height = 2304, 3584
    x = 2100
    
    # 确保x值在有效范围内
    x = max(0, min(x, width - crop_width))
    
    # 计算y值，确保裁剪是居中的
    y = (height - crop_height) // 2
    
    # 裁剪图片
    return img.crop((x, y, x + crop_width, y + crop_height))


if not os.path.exists(output_folder):
    os.mkdir(output_folder)

# 获取文件数
wenjian_num = len(os.listdir(folder1))

# 遍历文件夹中的每个图片文件
for i in range(1,wenjian_num+1):
    img_name = f'shiyan{i}.png'
    
    img1_path = os.path.join(folder1, img_name)
    img2_path = os.path.join(folder2, img_name)
    output_path = os.path.join(output_folder, f"{i}.jpg")
    
    # 打开并裁剪图片
    img1 = crop_image(Image.open(img1_path))
    img2 = crop_image(Image.open(img2_path))
    
    # 合并两张图片
    merged_width = img1.width + img2.width
    merged_img = Image.new('RGB', (merged_width, img1.height))
    merged_img.paste(img1, (0, 0))
    merged_img.paste(img2, (img1.width, 0))
    
    # 转换为灰度模式
    #gray_img = merged_img.convert('L')
    
    # 保存灰度图片
    merged_img.save(output_path, "JPEG")
