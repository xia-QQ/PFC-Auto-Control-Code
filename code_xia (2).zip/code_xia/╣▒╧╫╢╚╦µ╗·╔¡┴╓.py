#使用随机森林来分析特征对目标值影响
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split


# 读取CSV文件
def load_data(file_path):
    data = pd.read_csv(file_path)
    return data


# 构建模型并分析特征的贡献度
def analyze_feature_importances(data):
    # 目标值列
    target = data.iloc[:, 0]
    # 特征值列
    features = data.iloc[:, 1:]

    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

    # 创建随机森林回归器
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    # 拟合模型
    model.fit(X_train, y_train)

    # 获取每个特征的重要性
    importances = model.feature_importances_

    # 将特征名称和相应的重要性结合在一起
    feature_importances = zip(features.columns, importances)

    # 返回排序后的特征重要度列表
    return sorted(feature_importances, key=lambda x: x[1], reverse=True)


# 主函数
if __name__ == "__main__":
    # 假设CSV文件路径为'path_to_file.csv'
    file_path = r"D:\desktop\h.csv"
    data = load_data(file_path)
    importances = analyze_feature_importances(data)
    df = pd.DataFrame(importances, columns=['Feature', 'Importance'])
    df.to_excel(r'D:\desktop\Feature_Importance1.xlsx', index=False)
    # 打印每个特征的重要性
    for feature, importance in importances:
        print(f'Feature: {feature}, Importance: {importance}')
