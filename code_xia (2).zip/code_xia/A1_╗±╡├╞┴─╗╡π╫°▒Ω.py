import pyautogui

# 获取当前鼠标位置的坐标
x, y = pyautogui.position()
print("鼠标当前位置坐标：", x, y)
