import torch
import torch.nn as nn
import pandas as pd
from sklearn.preprocessing import StandardScaler
import numpy as np

# 使用列表推导处理每个列表内部的数学操作
X = [(x + 21.83) / 41.67 * 0.5 - 0.25 for x in [-7.2, -2.5, -11, 13.3, 10.9]]
Y = [(y + 41.7) / 83.3 - 0.5 for y in  [-24.1, -1.2, 38.7, 30.7, 3.0]]
J = [43.0, 159.0, 22.0, 81.0, 15.0]
L = [(z / 0.5 * 0.6 / 100) for z in [10.4,10.1,4.4,10.8,5.7]]
new_data_array = X+Y+J+L
# 输入数组

liewen_num = 5#裂纹数量，需要修改
data = pd.read_csv(r"E:\cl_xrd\合并数据.csv")# 加载数据
model_pth = "E:\cl_xrd\model.pth"#训练导出的pth

# 使用所有20个特征列
columns = ["Column"+str(i) for i in range(1, liewen_num*4+1)]
x_data = data[columns].values
y_data = data[["Min_Value", "Related_Value"]].values

# 标准化特征
scaler_x = StandardScaler()
x_data_scaled = scaler_x.fit_transform(x_data)

# 标准化输出
scaler_y = StandardScaler()
y_data_scaled = scaler_y.fit_transform(y_data)

# 定义神经网络模型
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3)
        self.fc1 = nn.Linear(16, 64)
        self.fc2 = nn.Linear(64, 2)

    def forward(self, x):
        x = self.conv1(x)
        x = nn.functional.relu(x)
        x = nn.functional.max_pool1d(x, kernel_size=x.size(-1))
        x = x.view(x.size(0), -1)
        x = nn.functional.relu(self.fc1(x))
        x = self.fc2(x)
        return x

model = CNN()
model.load_state_dict(torch.load(model_pth))
model.eval()

# 获取新数据作为输入
def get_prediction(new_data_array):
    assert len(new_data_array) == 20, "Input array must have 20 values"

    # 对新数据进行标准化处理
    new_data_scaled = scaler_x.transform([new_data_array])  # 注意，我们将输入数据转化为一个二维数组以进行标准化

    # 将新数据转换为张量
    x_new_tensor = torch.tensor(new_data_scaled, dtype=torch.float32).unsqueeze(1)

    # 对新数据进行预测
    with torch.no_grad():
        predicted_outputs_scaled = model(x_new_tensor)
        predicted_outputs = scaler_y.inverse_transform(predicted_outputs_scaled.numpy())  # 反标准化预测结果
    return predicted_outputs[0]

# 示例使用
predicted_outputs = get_prediction(new_data_array)
print("Predicted Outputs:")
print(predicted_outputs)
