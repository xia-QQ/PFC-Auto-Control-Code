from PIL import Image

# 打开一张图片
img = Image.open(r"D:\desktop\1.png")  # 将 'input.jpg' 替换为你的图片文件路径

# 将图片转换为 RGBA 模式以确保适用性
img = img.convert('RGBA')

# 加载图片的像素数据
pixels = img.load()

# 获取图片的尺寸
width, height = img.size

# 遍历每一个像素
for x in range(width):
    for y in range(height):
        # 获取当前像素的颜色值
        r, g, b, a = pixels[x, y]
        # 反转颜色值
        pixels[x, y] = (255 - r, 255 - g, 255 - b, a)

# 保存或显示反转后的图片
img.save(r"D:\desktop\11.png")  # 保存反转后的图片
img.show()  # 显示反转后的图片
