import subprocess
import threading
import time
import pyautogui
import pydirectinput as pd
import os
from concurrent.futures import ThreadPoolExecutor

total_folder = r"E:\5LX_XRD_AGE" # 总文件夹路径
num_b_folders = 400# 假设有n个B文件夹 


# 指定要运行的文件路径和程序路径
program_path = r"E:\soft\PFC5.0\exe64\pfc2d500_gui_64.exe"
def perform_operations():
    pyautogui.click(2527, 21)  # 保存文件
    time.sleep(3)
    pyautogui.click(1181, 727)
    time.sleep(3)
    pyautogui.click(1555, 859) 
    time.sleep(3)
    pyautogui.click(1253, 726)

def search_for_result_png(b_folder):
    while True:
        # 获取当前文件夹下的所有文件
        files = os.listdir(b_folder)
        
        if "result.png" in files:
            print("找到 result.png 文件，执行操作")
            break
        
        # 每隔一段时间检查一次
        time.sleep(50)


# 定义运行程序和点击操作的函数
def run_program(file_path_b):
    try:
        subprocess.run([program_path, file_path_b], shell=True)
    except Exception as e:
        print(f"运行文件时出错：{e}")

def simulate_mouse_click(b_folder):
    x_position = 406 
    y_position = 31 
    time.sleep(15)
    pyautogui.click(x_position, y_position)
    
    search_for_result_png(b_folder)
    perform_operations()
    


# 使用线程池管理线程
with ThreadPoolExecutor(max_workers=2) as executor:
    for i in range(1, num_b_folders + 1):
        b_folder = os.path.join(total_folder, f"shiyan{i}")
        file_path_b = os.path.join(b_folder, "main.p2prj")

        # 提交任务到线程池
        executor.submit(run_program, file_path_b)
        executor.submit(simulate_mouse_click,b_folder)

print(f"{num_b_folders} 个文件结束啦")
