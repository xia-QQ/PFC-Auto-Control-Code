import os
import csv

wenjian_num = 400#shiyan文件数，需要修改
liewen_num = 5#裂纹数量，需要修改

# 文件夹路径
folder_path = r"E:\cl_xrd\csv批处理"#csv批处理文件夹，需要修改
output_file_path = r"E:\cl_xrd\txt_output.csv"#所有txt处理结果，需要修改

yuan_path = r"E:\cl_xrd"
output_csv_path = os.path.join(yuan_path, "峰值应力应变.csv")#中间文件，需要修改
merged_csv_path = os.path.join(yuan_path, "合并数据.csv")#最终得到的UCS+UC+裂纹参数文件，需要修改



# 提取每个CSV文件的第三列和第四列数据，UCS+UC
def extract_data_from_csv(file_path):
    min_value = None
    related_value = None
    
    with open(file_path, 'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        for row in csv_reader:
            if len(row) >= 4:
                try:
                    value4 = float(row[3])
                    value3 = float(row[2])
                    if min_value is None or value4 < min_value:
                        min_value = value4
                        related_value = value3
                except ValueError:
                    pass  # 跳过无效行
    
    return min_value, related_value

# 遍历文件夹中的文件，提取数据并写入"峰值应力应变.csv"
data_list = []
for file_index in range(1, wenjian_num+1):
    file_name = f"{file_index}.csv"
    file_path = os.path.join(folder_path, file_name)
    
    min_value, related_value = extract_data_from_csv(file_path)
    data_list.append([min_value, related_value])

# 写入"峰值应力应变.csv"
with open(output_csv_path, 'w', newline='') as output_csv_file:
    csv_writer = csv.writer(output_csv_file)
    csv_writer.writerow(["Min_Value", "Related_Value"])
    csv_writer.writerows(data_list)



# 读取"output.csv"和"峰值应力应变.csv"的数据，并合并形成"合并数据.csv"
output_data = []
with open(output_file_path, 'r') as output_file:
    output_csv_reader = csv.reader(output_file)
    for row in output_csv_reader:
        # 删除24列数据中的序数列，根据所有txt处理结果的序数删除
        del row[(liewen_num+1)*3]
        del row[(liewen_num+1)*2]
        del row[liewen_num+1]
        del row[0]
        output_data.append(row)

merged_data = []
with open(output_csv_path, 'r') as data_source_file:
    data_source_csv_reader = csv.reader(data_source_file)
    next(data_source_csv_reader)  # 跳过标题行
    for data_row, output_row in zip(data_source_csv_reader, output_data):
        merged_row = data_row + output_row
        merged_data.append(merged_row)

# 写入"合并数据.csv"
header = ["Min_Value", "Related_Value"] + [f"Column{i}" for i in range(1, (liewen_num*4+1))]#插入所有txt处理结果里面的参数
with open(merged_csv_path, 'w', newline='') as merged_csv_file:
    csv_writer = csv.writer(merged_csv_file)
    csv_writer.writerow(header)
    csv_writer.writerows(merged_data)

print("合并任务完成！")
