from PIL import Image
import matplotlib.pyplot as plt

def crop_image(image_path, x, output_path):
    # 打开图片
    img = Image.open(image_path)

    # 图片原始尺寸
    width, height = img.size

    # 裁剪后的尺寸（此处选择256的倍数，例如4096x3072，这只是一个示例，你可以根据需要调整）
    crop_width, crop_height = 2304,3584
    
    # 确保x值在有效范围内
    x = max(0, min(x, width - crop_width))
    
    # 计算y值，确保裁剪是居中的
    y = (height - crop_height) // 2
    
    # 裁剪图片
    cropped_img = img.crop((x, y, x + crop_width, y + crop_height))
    
    # 保存裁剪后的图片
    cropped_img.save(output_path, "PNG")

    # 显示裁剪后的图片
    plt.imshow(cropped_img)
    plt.axis('off')  # 不显示坐标轴
    plt.show()

# 调用函数
image_path = r"E:\cl_xrd\result_png\shiyan1.png"  # 这里填写你的图片路径
output_path = r"D:\desktop\1.png"  # 输出图片的路径
crop_image(image_path, 2100, output_path)
