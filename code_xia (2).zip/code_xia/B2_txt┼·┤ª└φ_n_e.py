import os
import csv
import re

wenjian_num = 400#shiyan文件数，需要修改
folder_path = r"E:\5LX_XRD_AGE"# csv批处理文件夹路径，需要修改
txt_output_path = r"E:\cl_xrd\txt_output.csv"#输出文件夹路径，需要修改



# 定义函数将科学计数法表示的数字转化为小数
def scientific_to_decimal(s):
    # 分解数字为基数和指数部分
    base, exponent = s.split('e')
    return str(float(base) * (10 ** int(exponent)))

# 打开CSV文件用于写入
with open(txt_output_path, 'w', newline='') as csvfile:
    csv_writer = csv.writer(csvfile)

    for folder_index in range(1, wenjian_num+1):
        subfolder_path = os.path.join(folder_path, f"shiyan{folder_index}") 
        txt_path = os.path.join(subfolder_path, "output.txt")

        # 初始化一个列表用于存储提取的数字
        extracted_numbers = []
        # 打开output.txt文件并读取内容
        with open(txt_path, 'r') as txtfile:
            lines = txtfile.readlines()

            # 遍历每行文本
            for line in lines:
                # 使用正则表达式提取数字，包括科学计数法表示的数字
                numbers = re.findall(r'[-+]?\d*\.\d+(?:[eE][-+]?\d+)?|[-+]?\d+\.?\d*(?:[eE][-+]?\d+)?', line)

                # 转化科学计数法表示的数字
                for i, num in enumerate(numbers):
                    if 'e' in num or 'E' in num:
                        numbers[i] = scientific_to_decimal(num)

                extracted_numbers.extend(numbers)

        # 将提取的数字写入CSV文件，每个子文件夹占一行
        csv_writer.writerow(extracted_numbers)

print("CSV文件已生成")
