import pandas as pd
import ezdxf
import math

# 读取 Excel 文件
df = pd.read_excel('裂纹数据.xlsx')

# 创建一个新的 DXF 文档
doc = ezdxf.new()

# 获取模型空间
msp = doc.modelspace()

# 画一个长方形，长100，宽50，中心在坐标原点
rect_center = (0, 0)
rect_length = 50
rect_width = 100
rect_points = [
    (rect_center[0] - rect_length / 2, rect_center[1] - rect_width / 2),
    (rect_center[0] + rect_length / 2, rect_center[1] - rect_width / 2),
    (rect_center[0] + rect_length / 2, rect_center[1] + rect_width / 2),
    (rect_center[0] - rect_length / 2, rect_center[1] + rect_width / 2),
    (rect_center[0] - rect_length / 2, rect_center[1] - rect_width / 2),  # 闭合多边形
]
msp.add_lwpolyline(points=rect_points)

# 画线段
for _, row in df.iterrows():
    center = eval(row['Center'])  # 将字符串 '(x, y)' 转换为元组 (x, y)
    angle = row['Angle']
    length = row['Length']
    
    # 计算线段的起点和终点
    x1 = center[0] - length / 2 * math.cos(math.radians(-angle))
    y1 = center[1] - length / 2 * math.sin(math.radians(-angle))
    x2 = center[0] + length / 2 * math.cos(math.radians(-angle))
    y2 = center[1] + length / 2 * math.sin(math.radians(-angle))
    
    # 在模型空间中添加线段
    msp.add_line(start=(x1, y1), end=(x2, y2))

# 保存 DXF 文档
doc.saveas('样品6.dxf')
