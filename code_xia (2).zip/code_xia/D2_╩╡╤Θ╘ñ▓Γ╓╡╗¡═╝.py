import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import numpy as np

# 1. 从CSV文件加载数据
df = pd.read_csv(r"E:\cl_xrd\合并数据 - 验证.csv", encoding='GBK')#验证数据集文件
yanzheng_num = 30#验证数据集数据数量




# 2. 选择要用于散点图的两列数据
column1 = 'Min_Value'  # 用于红色散点图的列名
column2 = 'Related_Value'  # 用于蓝色散点图的列名
column3 = '预测1'  # 用于红色散点图的列名
column4 = '预测2'  # 用于蓝色散点图的列名

# 3. 获取选择的列数据并标准化处理
data_column1 = df[column1].values.reshape(-1, 1)
data_column1 = data_column1[~np.isnan(data_column1)]#删除空值
data_column1 = data_column1.reshape(yanzheng_num,1)

data_column2 = df[column2].values.reshape(-1, 1)
data_column2 = data_column2[~np.isnan(data_column2)]
data_column2 = data_column2.reshape(yanzheng_num,1)

data_column3 = df[column3].values.reshape(-1, 1)
data_column3 = data_column3[~np.isnan(data_column3)]
data_column3 = data_column3.reshape(yanzheng_num,1)

data_column4 = df[column4].values.reshape(-1, 1)
if data_column4[-1, 0] == '  ':
    data_column4 = data_column4[:-1]
data_column4 = data_column4.astype(float)# 将字符串数组转换为浮点数数组


scaler = StandardScaler()
data_column1_scaled = scaler.fit_transform(data_column1)
data_column2_scaled = scaler.fit_transform(data_column2)
data_column3_scaled = scaler.fit_transform(data_column3)
data_column4_scaled = scaler.fit_transform(data_column4)

# 4. 绘制散点图和连线
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(10, 6))
plt.scatter(data_column2_scaled, data_column1_scaled, c='red', label='实验值', marker='o')
plt.scatter(data_column4_scaled, data_column3_scaled, c='blue', label='对应预测值', marker='x')
plt.xlabel('极限应变（标准化）')
plt.ylabel('极限应力（标准化）')
plt.legend()

# 连接红色和蓝色散点
for i in range(len(data_column1_scaled)):
    plt.plot([data_column2_scaled[i], data_column4_scaled[i]], [data_column1_scaled[i], data_column3_scaled[i]], 'k-', lw=0.5)

plt.title('实验值和预测值分布')
plt.grid(True)

# 5. 显示图形
plt.show()
