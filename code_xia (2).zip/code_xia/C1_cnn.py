import torch
import torch.nn as nn
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import numpy as np


liewen_num = 5#裂纹数量，需要修改
model_pth = r"E:\cl_xrd\model.pth"#训练导出的pth
data = pd.read_csv(r"E:\cl_xrd\合并数据X.csv")#最终得到的UCS+UC+裂纹参数文件，需要修改


# 提取所有(liewen_num*4+1)个特征列
x_data = data[[f"Column{i}" for i in range(1, liewen_num*4+1)]].values
y_data = data[["Min_Value", "Related_Value"]].values

# 标准化特征
scaler_x = StandardScaler()
x_data_scaled = scaler_x.fit_transform(x_data)

# 标准化输出
scaler_y = StandardScaler()
y_data_scaled = scaler_y.fit_transform(y_data)

# 划分训练集和验证集
x_train, x_val, y_train, y_val = train_test_split(x_data_scaled, y_data_scaled, test_size=0.2, random_state=42)

# 将数据转换为张量
x_train_tensor = torch.tensor(x_train, dtype=torch.float32).unsqueeze(1)  # 添加通道维度
y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
x_val_tensor = torch.tensor(x_val, dtype=torch.float32).unsqueeze(1)  # 添加通道维度
y_val_tensor = torch.tensor(y_val, dtype=torch.float32)

# 定义神经网络模型
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3)  # 输入通道数为1
        self.fc1 = nn.Linear(16, 64)
        self.fc2 = nn.Linear(64, 2)  # 2个输出，分别对应UCS和应变

    def forward(self, x):
        x = self.conv1(x)
        x = nn.functional.relu(x)
        x = nn.functional.max_pool1d(x, kernel_size=x.size(-1))  # 使用动态的池化尺寸
        x = x.view(x.size(0), -1)
        x = nn.functional.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 创建模型和优化器
model = CNN()
optimizer = torch.optim.Adam(model.parameters(), lr=0.008)
criterion = nn.MSELoss()

# 训练模型
epochs = 100000
batch_size = 16
best_val_loss = float('inf')
patience = 60
no_improvement = 0
# 定义空列表来存储训练和验证损失
train_losses = []
val_losses = []

# 训练模型
for epoch in range(epochs):
    model.train()
    for i in range(0, len(x_train), batch_size):
        x_batch = x_train_tensor[i:i+batch_size]
        y_batch = y_train_tensor[i:i+batch_size]

        optimizer.zero_grad()
        outputs = model(x_batch)
        loss = criterion(outputs, y_batch)
        loss.backward()
        optimizer.step()

    with torch.no_grad():
        model.eval()
        val_outputs = model(x_val_tensor)
        val_loss = criterion(val_outputs, y_val_tensor)

    # 记录训练和验证损失
    train_losses.append(loss.item())
    val_losses.append(val_loss.item())
    
    if val_loss < best_val_loss:
        best_val_loss = val_loss
        no_improvement = 0
    else:
        no_improvement += 1
        if no_improvement >= patience:
            print(f"Early stopping: No improvement for {patience} epochs.")
            break

    print(f"Epoch [{epoch+1}/{epochs}], Loss: {loss.item():.4f}, Val Loss: {val_loss.item():.4f}")


# 绘制训练和验证损失曲线
plt.figure(figsize=(10, 5))
plt.plot(train_losses, label='Train Loss')
plt.plot(val_losses, label='Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Train and Validation Loss')
plt.legend()
plt.show()

with torch.no_grad():
    model.eval()
    val_outputs = model(x_val_tensor)
    val_outputs_unscaled = scaler_y.inverse_transform(val_outputs)
    y_val_unscaled = scaler_y.inverse_transform(y_val_tensor)

    # 绘制UCS的真实值与预测值
    plt.figure(figsize=(8, 8))
    plt.scatter(y_val_unscaled[:, 0], val_outputs_unscaled[:, 0], c='blue', label='UCS', alpha=0.7)
    plt.plot([min(y_val_unscaled[:, 0].min(), val_outputs_unscaled[:, 0].min()),
              max(y_val_unscaled[:, 0].max(), val_outputs_unscaled[:, 0].max())/2],
             [min(y_val_unscaled[:, 0].min(), val_outputs_unscaled[:, 0].min()),
              max(y_val_unscaled[:, 0].max(), val_outputs_unscaled[:, 0].max())/2],
             linestyle='--', color='gray', label='y=x')
    plt.xlabel('True UCS Values', fontsize=12)
    plt.ylabel('Predicted UCS Values', fontsize=12)
    plt.title('True UCS Values vs. Predicted UCS Values', fontsize=14)
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()

    # 绘制strain的真实值与预测值
    plt.figure(figsize=(8, 8))
    plt.scatter(y_val_unscaled[:, 1], val_outputs_unscaled[:, 1], c='red', label='Strain', alpha=0.7)
    plt.plot([min(y_val_unscaled[:, 1].min(), val_outputs_unscaled[:, 1].min()),
              max(y_val_unscaled[:, 1].max(), val_outputs_unscaled[:, 1].max())/2],
             [min(y_val_unscaled[:, 1].min(), val_outputs_unscaled[:, 1].min()),
              max(y_val_unscaled[:, 1].max(), val_outputs_unscaled[:, 1].max())/2],
             linestyle='--', color='gray', label='y=x')
    plt.xlabel('True Strain Values', fontsize=12)
    plt.ylabel('Predicted Strain Values', fontsize=12)
    plt.title('True Strain Values vs. Predicted Strain Values', fontsize=14)
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()

# 保存模型
torch.save(model.state_dict(), model_pth)