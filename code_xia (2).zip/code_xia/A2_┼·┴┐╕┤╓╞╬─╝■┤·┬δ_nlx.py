
import os
import shutil



total_folder = r"E:\5LX_XRD_AGE"
n = 400



if not os.path.exists(total_folder):
    os.mkdir(total_folder)

for i in range(1, n+1):
    subfolder_name = "shiyan"+str(i)
    subfolder_path = os.path.join(total_folder, subfolder_name)
    os.mkdir(subfolder_path)

    source_folder = r"D:\desktop\PFC_XRD_nlx_delete - cai"
    for root, _, files in os.walk(source_folder):
        for file in files:
            source_file_path = os.path.join(root, file)
            target_file_path = os.path.join(subfolder_path, file)
            shutil.copy(source_file_path, target_file_path)
